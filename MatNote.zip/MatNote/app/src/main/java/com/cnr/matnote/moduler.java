package com.cnr.matnote;

public class moduler extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "moduler/";
    }

    @Override
    protected int getKacTaneResim() {
        return 14;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.moduler;
    }
}