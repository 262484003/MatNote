package com.cnr.matnote;

public class yuzdefaiz extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "yuzdefaiz/";
    }

    @Override
    protected int getKacTaneResim() {
        return 29;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.yuzdefaiz;
    }
}