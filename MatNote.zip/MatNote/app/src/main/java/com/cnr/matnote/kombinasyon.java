package com.cnr.matnote;

public class kombinasyon extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "kombinasyon/";
    }

    @Override
    protected int getKacTaneResim() {
        return 29;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.kombinasyon;
    }
}