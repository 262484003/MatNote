package com.cnr.matnote;

public class polinom extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "polinom/";
    }

    @Override
    protected int getKacTaneResim() {
        return 50;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.polinom;
    }
}