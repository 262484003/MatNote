package com.cnr.matnote;

public class Tabanaritmetigi extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "tabanaritmetigi/";
    }

    @Override
    protected int getKacTaneResim() {
        return 15;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.tabanaritmetigi;
    }
}