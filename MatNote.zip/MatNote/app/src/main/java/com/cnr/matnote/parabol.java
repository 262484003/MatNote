package com.cnr.matnote;

public class parabol extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "parabol/";
    }

    @Override
    protected int getKacTaneResim() {
        return 41;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.parabol;
    }
}