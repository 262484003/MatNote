package com.cnr.matnote;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.cnr.matnote.TouchImageView.OnTouchImageViewListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

public class binom extends Activity {
    private static final int KAC_TANE_RESIM = 15;
    
    private TouchImageView image;
    private String kartyol = "";
    private int sayfaNo = 1;
    private ImageLoader task = null;
    private TextView txtKacincida;
    private String uzanti;

    public class ImageLoader extends AsyncTask<Void, Void, Bitmap> {
        private final String url;
        private final Context context;
        private InputStream in;

        ImageLoader(Context context, String url) {
            this.url = url;
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            try {
                in = context.getAssets().open(url);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected Bitmap doInBackground(Void... arg0) {
            Bitmap bitmap = null;
            if (in != null) {
                try {
                    bitmap = BitmapFactory.decodeStream(in);
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap result) {
            if (isFinishing() || result == null) return;

            image.setImageBitmap(result);
            Log.d("mesaj", "resim tamam-" + image.getCurrentZoom());
            
            if (image.getCurrentZoom() != 1.0f) {
                image.setZoom(1.0f);
            }
            txtKacincida.setText(String.format(Locale.getDefault(), "%d/%d", sayfaNo, KAC_TANE_RESIM));
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.binom);

        AdView adView = findViewById(R.id.adView);
        adView.loadAd(new AdRequest.Builder().build());

        image = findViewById(R.id.imageView1);
        image.setOnTouchImageViewListener(new OnTouchImageViewListener() {
            @Override
            public void onMove() {
                PointF point = image.getScrollPosition();
                RectF rect = image.getZoomedRect();
                float currentZoom = image.getCurrentZoom();
                boolean isZoomed = image.isZoomed();
            }
        });

        txtKacincida = findViewById(R.id.txtKacincida);
        kartyol = "binom/";
        uzanti = ".png";
        
        Button btnOnceki = findViewById(R.id.btnOnceki);
        Button btnSonraki = findViewById(R.id.btnSonraki);

        txtKacincida.setText(String.format(Locale.getDefault(), "%d/%d", sayfaNo, KAC_TANE_RESIM));
        executeNewTask();

        btnOnceki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sayfaNo--;
                if (sayfaNo == 0) {
                    sayfaNo = KAC_TANE_RESIM;
                }
                executeNewTask();
            }
        });

        btnSonraki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sayfaNo++;
                if (sayfaNo == KAC_TANE_RESIM + 1) {
                    sayfaNo = 1;
                }
                executeNewTask();
            }
        });
    }

    private void executeNewTask() {
        if (task != null) {
            task.cancel(true);
        }
        task = new ImageLoader(getApplicationContext(), kartyol + sayfaNo + uzanti);
        task.execute();
    }
}