package com.cnr.matnote;

public class trigoiki extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "trigoiki/";
    }

    @Override
    protected int getKacTaneResim() {
        return 42;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.trigoiki;
    }
}