package com.cnr.matnote;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.io.IOException;
import java.io.InputStream;

public abstract class BaseImageActivity extends Activity {
    protected TouchImageView image;
    protected TextView txtKacincida;
    protected Button btnOnceki;
    protected Button btnSonraki;
    
    protected int sayfaNo = 1;
    protected ImageLoader task = null;
    protected final String uzanti = ".png";

    // Her alt sınıf kendi özel değerlerini bu metotlarla üst sınıfa bildirecek
    protected abstract String getKartYol();
    protected abstract int getKacTaneResim();
    protected abstract int getLayoutId();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutId());

        image = (TouchImageView) findViewById(R.id.imageView1);
        txtKacincida = (TextView) findViewById(R.id.txtKacincida);
        btnOnceki = (Button) findViewById(R.id.btnOnceki);
        btnSonraki = (Button) findViewById(R.id.btnSonraki);

        // İlk resmi yükle
        resimYukle();

        btnOnceki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sayfaNo--;
                if (sayfaNo == 0) {
                    sayfaNo = getKacTaneResim();
                }
                resimYukle();
            }
        });

        btnSonraki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sayfaNo++;
                if (sayfaNo == getKacTaneResim() + 1) {
                    sayfaNo = 1;
                }
                resimYukle();
            }
        });
    }

    private void resimYukle() {
        if (task != null) {
            task.cancel(true);
        }
        String tamYol = getKartYol() + sayfaNo + uzanti;
        task = new ImageLoader(tamYol);
        task.execute();
    }

    // Ortak resim yükleme asenkron görevi (Hafıza sızıntısı önlenmiş hali)
    private class ImageLoader extends AsyncTask<Void, Void, Bitmap> {
        private final String url;

        ImageLoader(String url) {
            this.url = url;
        }

        @Override
        protected Bitmap doInBackground(Void... voids) {
            Bitmap bitmap = null;
            InputStream in = null;
            try {
                in = getAssets().open(url);
                bitmap = BitmapFactory.decodeStream(in);
            } catch (IOException e) {
                Log.e("BaseImageActivity", "Resim yukleme hatasi: " + url, e);
            } finally {
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap result) {
            if (isCancelled()) return;
            
            if (result != null && image != null) {
                image.setImageBitmap(result);
                if (image.getCurrentZoom() != 1.0f) {
                    image.setZoom(1.0f);
                }
            }
            if (txtKacincida != null) {
                txtKacincida.setText(sayfaNo + "/" + getKacTaneResim());
            }
        }
    }
}