package com.cnr.matnote;

public class Temelkavramlar extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "temelkavramlar/";
    }

    @Override
    protected int getKacTaneResim() {
        return 41;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.temelkavramlar;
    }
}