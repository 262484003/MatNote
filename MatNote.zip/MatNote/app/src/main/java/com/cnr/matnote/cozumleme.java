package com.cnr.matnote;

public class cozumleme extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "cozumleme/";
    }

    @Override
    protected int getKacTaneResim() {
        return 16;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.cozumleme;
    }
}