package com.cnr.matnote;

public class kumeler extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "kumeler/";
    }

    @Override
    protected int getKacTaneResim() {
        return 48;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.kumeler;
    }
}