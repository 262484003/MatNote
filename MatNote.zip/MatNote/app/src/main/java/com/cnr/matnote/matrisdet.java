package com.cnr.matnote;

public class matrisdet extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "matrisdet/";
    }

    @Override
    protected int getKacTaneResim() {
        return 42;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.matrisdet;
    }
}