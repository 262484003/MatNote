package com.cnr.matnote;

public class carpanlar extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "carpanlar/";
    }

    @Override
    protected int getKacTaneResim() {
        return 24;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.carpanlar;
    }
}