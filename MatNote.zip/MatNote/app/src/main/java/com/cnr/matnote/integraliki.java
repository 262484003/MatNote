package com.cnr.matnote;

public class integraliki extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "integraliki/";
    }

    @Override
    protected int getKacTaneResim() {
        return 22;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.integraliki;
    }
}