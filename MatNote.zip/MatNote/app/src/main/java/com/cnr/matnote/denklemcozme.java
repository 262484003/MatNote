package com.cnr.matnote;

public class denklemcozme extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "birinciderecedendenklemler/";
    }

    @Override
    protected int getKacTaneResim() {
        return 33;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.denklemcozme;
    }
}