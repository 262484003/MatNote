package com.cnr.matnote;

public class mantik extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "mantik/";
    }

    @Override
    protected int getKacTaneResim() {
        return 22;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.mantik;
    }
}