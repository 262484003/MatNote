package com.cnr.matnote;

public class toplamcarpim extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "toplamcarpim/";
    }

    @Override
    protected int getKacTaneResim() {
        return 28;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.toplamcarpim;
    }
}