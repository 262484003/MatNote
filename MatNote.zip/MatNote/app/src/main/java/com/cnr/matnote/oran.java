package com.cnr.matnote;

public class oran extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "oran/";
    }

    @Override
    protected int getKacTaneResim() {
        return 26;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.oran;
    }
}