package com.cnr.matnote;

public class integralbir extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "integralbir/";
    }

    @Override
    protected int getKacTaneResim() {
        return 54;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.integralbir;
    }
}