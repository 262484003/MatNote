package com.cnr.matnote;

public class diziler extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "diziler/";
    }

    @Override
    protected int getKacTaneResim() {
        return 40;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.diziler;
    }
}