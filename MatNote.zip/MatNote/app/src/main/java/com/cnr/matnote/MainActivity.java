package com.cnr.matnote;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Doğrudan Anaekran'a yönlendiriyoruz, 3 saniyelik beklemeyi ve çökme risklerini sildik.
        Intent intent = new Intent(this, Anaekran.class);
        startActivity(intent);
        finish();
    }
}