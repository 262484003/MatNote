package com.cnr.matnote;

public class turevbir extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "turevbir/";
    }

    @Override
    protected int getKacTaneResim() {
        return 51;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.turevbir;
    }
}