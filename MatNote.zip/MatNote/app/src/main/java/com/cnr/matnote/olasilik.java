package com.cnr.matnote;

public class olasilik extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "olasilik/";
    }

    @Override
    protected int getKacTaneResim() {
        return 34;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.olasilik;
    }
}