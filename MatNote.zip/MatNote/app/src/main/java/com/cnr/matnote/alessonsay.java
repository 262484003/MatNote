package com.cnr.matnote;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class alessonsay extends Activity {
    private static final long MILLIS_IN_DAY = 86400000;
    private static final long MILLIS_IN_HOUR = 3600000;
    private static final long MILLIS_IN_MINUTE = 60000;

    private Handler handler;
    private LinearLayout linearLayout1;
    private LinearLayout linearLayout2;
    private Runnable runnable;
    private TextView tvDay;
    private TextView tvEvent;
    private TextView tvHour;
    private TextView tvMinute;
    private TextView tvSecond;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alessonsay);
        initUI();
        countDownStart();
    }

    @SuppressLint({"SimpleDateFormat"})
    private void initUI() {
        linearLayout1 = (LinearLayout) findViewById(R.id.ll1);
        linearLayout2 = (LinearLayout) findViewById(R.id.ll2);
        tvDay = (TextView) findViewById(R.id.txtTimerDay);
        tvHour = (TextView) findViewById(R.id.txtTimerHour);
        tvMinute = (TextView) findViewById(R.id.txtTimerMinute);
        tvSecond = (TextView) findViewById(R.id.txtTimerSecond);
        tvEvent = (TextView) findViewById(R.id.tvevent);
    }

    public void countDownStart() {
        handler = new Handler(Looper.getMainLooper());
        runnable = new Runnable() {
            @Override
            public void run() {
                handler.postDelayed(this, 1000);
                try {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    Date futureDate = dateFormat.parse("2026-11-22");
                    Date currentDate = new Date();

                    if (currentDate.after(futureDate)) {
                        linearLayout1.setVisibility(View.VISIBLE);
                        linearLayout2.setVisibility(View.GONE);
                        tvEvent.setText("Sınavda Başarılar Dilerim.");
                        handler.removeCallbacks(runnable);
                        return;
                    }

                    long diff = futureDate.getTime() - currentDate.getTime();

                    long days = diff / MILLIS_IN_DAY;
                    diff -= MILLIS_IN_DAY * days;

                    long hours = diff / MILLIS_IN_HOUR;
                    diff -= MILLIS_IN_HOUR * hours;

                    long minutes = diff / MILLIS_IN_MINUTE;
                    long seconds = (diff - (MILLIS_IN_MINUTE * minutes)) / 1000;

                    tvDay.setText(String.format(Locale.getDefault(), "%02d", days));
                    tvHour.setText(String.format(Locale.getDefault(), "%02d", hours));
                    tvMinute.setText(String.format(Locale.getDefault(), "%02d", minutes));
                    tvSecond.setText(String.format(Locale.getDefault(), "%02d", seconds));

                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        };
        handler.postDelayed(runnable, 0);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handler != null && runnable != null) {
            handler.removeCallbacks(runnable);
        }
    }
}