package com.cnr.matnote;

public class yas extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "yasproblemleri/";
    }

    @Override
    protected int getKacTaneResim() {
        return 18;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.yas;
    }
}