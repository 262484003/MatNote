package com.cnr.matnote;

public class obebokek extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "obebokek/";
    }

    @Override
    protected int getKacTaneResim() {
        return 24;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.obebokek;
    }
}