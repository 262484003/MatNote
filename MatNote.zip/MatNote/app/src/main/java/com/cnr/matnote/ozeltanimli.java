package com.cnr.matnote;

public class ozeltanimli extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "ozeltanimli/";
    }

    @Override
    protected int getKacTaneResim() {
        return 28;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.ozeltanimli;
    }
}