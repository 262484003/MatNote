package com.cnr.matnote;

public class ikincideresit extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "ikincideresit/";
    }

    @Override
    protected int getKacTaneResim() {
        return 33;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.ikincideresit;
    }
}