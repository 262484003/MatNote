package com.cnr.matnote;

public class limit extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "limit/";
    }

    @Override
    protected int getKacTaneResim() {
        return 35;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.limit;
    }
}