package com.cnr.matnote;

public class rasyonel extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "rasyonel/";
    }

    @Override
    protected int getKacTaneResim() {
        return 23;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.rasyonel;
    }
}