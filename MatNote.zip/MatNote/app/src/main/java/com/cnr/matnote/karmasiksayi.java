package com.cnr.matnote;

public class karmasiksayi extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "karmasiksayi/";
    }

    @Override
    protected int getKacTaneResim() {
        return 55;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.karmasiksayi;
    }
}