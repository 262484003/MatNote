package com.cnr.matnote;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

public class gerisayim extends Activity {
    private AdRequest adRe;
    private InterstitialAd gecisReklam;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gerisayim);

        AdView adView = findViewById(R.id.adView);
        adView.loadAd(new AdRequest.Builder().build());

        findViewById(R.id.button1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showGecisReklam();
                startActivity(new Intent(gerisayim.this, ygssay.class));
            }
        });

        findViewById(R.id.button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showGecisReklam();
                startActivity(new Intent(gerisayim.this, lyssay.class));
            }
        });

        findViewById(R.id.button3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showGecisReklam();
                startActivity(new Intent(gerisayim.this, kpsslisanssay.class));
            }
        });

        findViewById(R.id.button4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showGecisReklam();
                startActivity(new Intent(gerisayim.this, kpssoabtsay.class));
            }
        });

        findViewById(R.id.button5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showGecisReklam();
                startActivity(new Intent(gerisayim.this, kpssonlisanssay.class));
            }
        });

        findViewById(R.id.button6).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showGecisReklam();
                startActivity(new Intent(gerisayim.this, kpsslisesay.class));
            }
        });

        findViewById(R.id.button7).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showGecisReklam();
                startActivity(new Intent(gerisayim.this, kpssdinsay.class));
            }
        });

        findViewById(R.id.button8).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showGecisReklam();
                startActivity(new Intent(gerisayim.this, dgssay.class));
            }
        });

        findViewById(R.id.button9).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showGecisReklam();
                startActivity(new Intent(gerisayim.this, alesilksay.class));
            }
        });

        findViewById(R.id.button10).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showGecisReklam();
                startActivity(new Intent(gerisayim.this, alessonsay.class));
            }
        });

        findViewById(R.id.button11).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showGecisReklam();
                startActivity(new Intent(gerisayim.this, alssay.class));
            }
        });

        adRe = new AdRequest.Builder().build();
        gecisReklam = new InterstitialAd(this);
        gecisReklam.setAdUnitId("ca-app-pub-5886370437059936/1692395608");
        gecisReklam.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                gecisReklam.loadAd(adRe);
            }
        });
        loadGecisReklam();
    }

    @Override
    public void onBackPressed() {
        showGecisReklam();
        super.onBackPressed();
    }

    public void loadGecisReklam() {
        if (gecisReklam != null) {
            gecisReklam.loadAd(adRe);
        }
    }

    public void showGecisReklam() {
        if (gecisReklam != null && gecisReklam.isLoaded()) {
            gecisReklam.show();
        }
    }
}