package com.cnr.matnote;

public class trigouc extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "trigouc/";
    }

    @Override
    protected int getKacTaneResim() {
        return 25;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.trigouc;
    }
}