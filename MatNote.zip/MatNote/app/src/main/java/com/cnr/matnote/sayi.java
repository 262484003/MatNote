package com.cnr.matnote;

public class sayi extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "sayiproblemleri/";
    }

    @Override
    protected int getKacTaneResim() {
        return 23;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.sayi;
    }
}