package com.cnr.matnote;

public class ikinciderdenk extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "ikinciderdenk/";
    }

    @Override
    protected int getKacTaneResim() {
        return 31;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.ikinciderdenk;
    }
}