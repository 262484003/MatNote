package com.cnr.matnote;

public class fonksiyon extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "fonksiyon/";
    }

    @Override
    protected int getKacTaneResim() {
        return 43;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fonksiyon;
    }
}