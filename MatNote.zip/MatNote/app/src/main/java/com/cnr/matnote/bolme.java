package com.cnr.matnote;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.cnr.matnote.TouchImageView.OnTouchImageViewListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public abstract class BaseImageActivity extends Activity {
    private TouchImageView image;
    private TextView txtKacincida;
    private int sayfaNo = 1;

    private ExecutorService executorService;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // Alt sınıfların (asal, bolme vb.) doldurması zorunlu olan dinamik alanlar
    protected abstract String getKartYol();
    protected abstract int getKacTaneResim();
    protected abstract int getLayoutId();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutId());

        executorService = Executors.newSingleThreadExecutor();

        AdView adView = findViewById(R.id.adView);
        if (adView != null) {
            adView.loadAd(new AdRequest.Builder().build());
        }

        image = findViewById(R.id.imageView1);
        if (image != null) {
            image.setOnTouchImageViewListener(new OnTouchImageViewListener() {
                @Override
                public void onMove() {
                    PointF point = image.getScrollPosition();
                    RectF rect = image.getZoomedRect();
                    float currentZoom = image.getCurrentZoom();
                    boolean isZoomed = image.isZoomed();
                }
            });
        }

        txtKacincida = findViewById(R.id.txtKacincida);
        Button btnOnceki = findViewById(R.id.btnOnceki);
        Button btnSonraki = findViewById(R.id.btnSonraki);

        updateText();
        loadImage();

        if (btnOnceki != null) {
            btnOnceki.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sayfaNo--;
                    if (sayfaNo == 0) {
                        sayfaNo = getKacTaneResim();
                    }
                    updateText();
                    loadImage();
                }
            });
        }

        if (btnSonraki != null) {
            btnSonraki.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sayfaNo++;
                    if (sayfaNo == getKacTaneResim() + 1) {
                        sayfaNo = 1;
                    }
                    updateText();
                    loadImage();
                }
            });
        }
    }

    private void updateText() {
        if (txtKacincida != null) {
            txtKacincida.setText(String.format(Locale.getDefault(), "%d/%d", sayfaNo, getKacTaneResim()));
        }
    }

    private void loadImage() {
        final String fullPath = getKartYol() + sayfaNo + ".png";

        executorService.execute(new Runnable() {
            @Override
            public void run() {
                Bitmap bitmap = null;
                InputStream in = null;
                try {
                    in = getAssets().open(fullPath);
                    bitmap = BitmapFactory.decodeStream(in);
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (in != null) {
                        try {
                            in.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }

                final Bitmap finalBitmap = bitmap;
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing() || finalBitmap == null || image == null) return;

                        image.setImageBitmap(finalBitmap);
                        Log.d("mesaj", "resim tamam-" + image.getCurrentZoom());

                        if (image.getCurrentZoom() != 1.0f) {
                            image.setZoom(1.0f);
                        }
                    }
                });
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdownNow(); // Arka plandaki tüm işlemleri zorla durdur, sızıntıyı kes
        }
    }
}