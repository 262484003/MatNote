package com.cnr.matnote;

public class trigobir extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "trigobir/";
    }

    @Override
    protected int getKacTaneResim() {
        return 47;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.trigobir;
    }
}