package com.cnr.matnote;

public class trigodort extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "trigodort/";
    }

    @Override
    protected int getKacTaneResim() {
        return 19;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.trigodort;
    }
}