package com.cnr.matnote;

public class permutasyon extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "permutasyon/";
    }

    @Override
    protected int getKacTaneResim() {
        return 31;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.permutasyon;
    }
}