package com.cnr.matnote;

public class mutlak extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "mutlakdeger/";
    }

    @Override
    protected int getKacTaneResim() {
        return 22;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.mutlak;
    }
}