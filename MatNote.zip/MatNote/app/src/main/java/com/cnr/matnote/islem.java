package com.cnr.matnote;

public class islem extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "islem/";
    }

    @Override
    protected int getKacTaneResim() {
        return 20;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.islem;
    }
}