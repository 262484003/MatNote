package com.cnr.matnote;

public class hareket extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "hareket/";
    }

    @Override
    protected int getKacTaneResim() {
        return 29;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.hareket;
    }
}