package com.cnr.matnote;

public class tureviki extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "tureviki/";
    }

    @Override
    protected int getKacTaneResim() {
        return 62;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.tureviki;
    }
}