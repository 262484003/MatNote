package com.cnr.matnote;

public class kesir extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "kesirproblemleri/";
    }

    @Override
    protected int getKacTaneResim() {
        return 13;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.kesir;
    }
}