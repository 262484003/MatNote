package com.cnr.matnote;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class Anaekran extends Activity {
    private AdRequest adRequest;
    private InterstitialAd gecisReklam;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.anaekran);

        ((Button) findViewById(R.id.button1)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showGecisReklam();
                startActivity(new Intent(Anaekran.this, Ygsmat.class));
            }
        });

        ((Button) findViewById(R.id.button2)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showGecisReklam();
                startActivity(new Intent(Anaekran.this, Lysmat.class));
            }
        });

        ((Button) findViewById(R.id.button4)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showGecisReklam();
                startActivity(new Intent(Anaekran.this, gerisayim.class));
            }
        });

        ((Button) findViewById(R.id.button5)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                showGecisReklam();
                startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.cnr.videomatik")));
            }
        });

        adRequest = new AdRequest.Builder().build();
        loadGecisReklam();
    }

    @Override
    public void onBackPressed() {
        showGecisReklam();
        super.onBackPressed();
    }

    public void loadGecisReklam() {
        InterstitialAd.load(this, "ca-app-pub-5886370437059936/1692395608", adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        gecisReklam = interstitialAd;
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        gecisReklam = null;
                    }
                });
    }

    public void showGecisReklam() {
        if (gecisReklam != null) {
            gecisReklam.show(this);
            loadGecisReklam();
        }
    }
}