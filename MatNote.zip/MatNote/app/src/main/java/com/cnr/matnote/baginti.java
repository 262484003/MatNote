package com.cnr.matnote;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.cnr.matnote.TouchImageView.OnTouchImageViewListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.Locale;

public class baginti extends Activity {
    private static final int KAC_TANE_RESIM = 23;
    private AdView adView;
    private TouchImageView image;
    private String kartyol = "";
    private int sayfaNo = 1;
    private ImageLoader task = null;
    private TextView txtKacincida;
    private String uzanti;

    public static class ImageLoader extends AsyncTask<Void, Void, Bitmap> {
        private final String url;
        private final WeakReference<Context> contextRef;
        private final WeakReference<baginti> activityRef;
        private InputStream in;

        ImageLoader(baginti activity, Context context, String url) {
            this.activityRef = new WeakReference<>(activity);
            this.contextRef = new WeakReference<>(context);
            this.url = url;
        }

        @Override
        protected void onPreExecute() {
            Context context = contextRef.get();
            if (context != null) {
                try {
                    in = context.getAssets().open(url);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        @Override
        protected Bitmap doInBackground(Void... arg0) {
            Bitmap bitmap = null;
            if (in != null) {
                try {
                    bitmap = BitmapFactory.decodeStream(in);
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap result) {
            baginti activity = activityRef.get();
            if (activity != null && !activity.isFinishing() && result != null) {
                activity.image.setImageBitmap(result);
                Log.d("mesaj", "resim tamam-" + activity.image.getCurrentZoom());
                if (activity.image.getCurrentZoom() != 1.0f) {
                    activity.image.setZoom(1.0f);
                }
                activity.txtKacincida.setText(String.format(Locale.getDefault(), "%d/%d", activity.sayfaNo, KAC_TANE_RESIM));
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.baginti);

        adView = (AdView) findViewById(R.id.adView);
        adView.loadAd(new AdRequest.Builder().build());

        image = (TouchImageView) findViewById(R.id.imageView1);
        image.setOnTouchImageViewListener(new OnTouchImageViewListener() {
            @Override
            public void onMove() {
                PointF point = image.getScrollPosition();
                RectF rect = image.getZoomedRect();
                float currentZoom = image.getCurrentZoom();
                boolean isZoomed = image.isZoomed();
            }
        });

        txtKacincida = (TextView) findViewById(R.id.txtKacincida);
        kartyol = "baginti/";
        uzanti = ".png";
        
        Button btnOnceki = (Button) findViewById(R.id.btnOnceki);
        Button btnSonraki = (Button) findViewById(R.id.btnSonraki);

        txtKacincida.setText(String.format(Locale.getDefault(), "%d/%d", sayfaNo, KAC_TANE_RESIM));
        loadImage();

        btnOnceki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sayfaNo--;
                if (sayfaNo == 0) {
                    sayfaNo = KAC_TANE_RESIM;
                }
                loadImage();
            }
        });

        btnSonraki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sayfaNo++;
                if (sayfaNo == KAC_TANE_RESIM + 1) {
                    sayfaNo = 1;
                }
                loadImage();
            }
        });
    }

    private void loadImage() {
        if (task != null) {
            task.cancel(true);
        }
        task = new ImageLoader(this, getApplicationContext(), kartyol + sayfaNo + uzanti);
        task.execute();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (task != null) {
            task.cancel(true);
        }
    }
}