package com.cnr.matnote;

public class logaritma extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "logaritma/";
    }

    @Override
    protected int getKacTaneResim() {
        return 32;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.logaritma;
    }
}