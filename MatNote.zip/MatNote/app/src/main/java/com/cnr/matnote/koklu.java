package com.cnr.matnote;

public class koklu extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "koklu/";
    }

    @Override
    protected int getKacTaneResim() {
        return 35;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.koklu;
    }
}