package com.cnr.matnote;

public class iscihavuz extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "iscihavuz/";
    }

    @Override
    protected int getKacTaneResim() {
        return 23;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.iscihavuz;
    }
}