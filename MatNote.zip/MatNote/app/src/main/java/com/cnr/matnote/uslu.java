package com.cnr.matnote;

public class uslu extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "uslu/";
    }

    @Override
    protected int getKacTaneResim() {
        return 31;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.uslu;
    }
}