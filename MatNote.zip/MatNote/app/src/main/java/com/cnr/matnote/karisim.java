package com.cnr.matnote;

public class karisim extends BaseImageActivity {
    @Override
    protected String getKartYol() {
        return "karisim/";
    }

    @Override
    protected int getKacTaneResim() {
        return 21;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.karisim;
    }
}